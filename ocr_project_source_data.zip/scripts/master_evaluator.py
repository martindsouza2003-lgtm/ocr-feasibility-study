import os
import glob
import pandas as pd
import sys
import gc
import time

# Ensure Python can find custom scripts
sys.path.append(os.path.dirname(__file__))

# Imports
from metrics_tracker import calculate_error_rates, get_current_ram_mb, ResourceMonitor, normalize_text # ✅ Fixed Import
from nextgen_engines import load_trocr_model, run_trocr

try:
    from ocr_engines import run_tesseract, run_easyocr, run_paddleocr
    LEGACY_ENGINES_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Warning: Could not load legacy engines ({e}). Running TrOCR only.")
    LEGACY_ENGINES_AVAILABLE = False


# ==========================================
# PATH CONFIG
# ==========================================
DATASET_IMG_DIR = "dataset/images"
DATASET_GT_DIR = "dataset/ground_truth"
RESULTS_DIR = "results"


# ==========================================
# LOAD GROUND TRUTH
# ==========================================
def read_ground_truth(image_filename):
    base_name = os.path.splitext(image_filename)[0]
    txt_path = os.path.join(DATASET_GT_DIR, f"{base_name}.txt")

    if os.path.exists(txt_path):
        with open(txt_path, 'r', encoding='utf-8') as f:
            return f.read().strip()  # ✅ FIXED
    return None


# ==========================================
# MODEL EVALUATION WRAPPER
# ==========================================
def evaluate_model(model_name, func, gt_text, *args):
    print(f"   -> Running {model_name}...")

    monitor = ResourceMonitor()

    # RAM before
    ram_before = get_current_ram_mb()

    # Start CPU monitor
    monitor.start()
    time.sleep(0.05)  # ✅ stabilize CPU sampling

    # Run model
    try:
        predicted_text, exec_time = func(*args)
    except Exception as e:
        print(f"      ❌ Error in {model_name}: {e}")
        predicted_text, exec_time = "ERROR", 0.0

    # Stop monitor
    avg_cpu = monitor.stop()
    ram_after = get_current_ram_mb()

    ram_delta = max(0.0, ram_after - ram_before)

    # Normalize BEFORE metrics (extra safety)
    gt_clean = normalize_text(gt_text)
    pred_clean = normalize_text(predicted_text)

    cer, wer = calculate_error_rates(gt_clean, pred_clean)

    gc.collect()

    return {
        f"{model_name}_CER": cer,
        f"{model_name}_WER": wer,
        f"{model_name}_Time": round(exec_time, 2),
        f"{model_name}_RAM_MB": round(ram_delta, 2),
        f"{model_name}_CPU_%": avg_cpu
    }, pred_clean


# ==========================================
# MAIN PIPELINE
# ==========================================
def main():
    print("=" * 60)
    print("🚀 STARTING OCR EVALUATION PIPELINE")
    print("=" * 60)

    os.makedirs(RESULTS_DIR, exist_ok=True)

    # ✅ Sorted images for consistency
    image_paths = sorted(glob.glob(os.path.join(DATASET_IMG_DIR, "*.*")))

    if not image_paths:
        print("❌ No images found")
        return

    # Load TrOCR
    trocr_processor, trocr_model = load_trocr_model()

    all_results = []

    for idx, img_path in enumerate(image_paths):
        img_filename = os.path.basename(img_path)
        print(f"\n📄 Processing: {img_filename}")

        gt_text = read_ground_truth(img_filename)
        if not gt_text:
            print("   ⚠️ Skipping (no GT)")
            continue

        row_data = {"Image_Name": img_filename}

        # ===============================
        # TrOCR
        # ===============================
        result, pred = evaluate_model(
            "TrOCR",
            run_trocr,
            gt_text,
            img_path,
            trocr_processor,
            trocr_model
        )
        row_data.update(result)

        # Debug sample (Phase 10)
        if idx < 3:
            print("   🔍 DEBUG SAMPLE")
            print(f"   GT   : {gt_text[:80]}")
            print(f"   Pred : {pred[:80]}")

        # ===============================
        # LEGACY MODELS
        # ===============================
        if LEGACY_ENGINES_AVAILABLE:

            # Tesseract Raw
            result, _ = evaluate_model(
                "Tess_Raw",
                run_tesseract,
                gt_text,
                img_path,
                False
            )
            row_data.update(result)

            # Tesseract Processed
            result, _ = evaluate_model(
                "Tess_Proc",
                run_tesseract,
                gt_text,
                img_path,
                True
            )
            row_data.update(result)

            # EasyOCR
            result, _ = evaluate_model(
                "EasyOCR",
                run_easyocr,
                gt_text,
                img_path
            )
            row_data.update(result)

            # PaddleOCR (safe)
            try:
                result, _ = evaluate_model(
                    "PaddleOCR",
                    run_paddleocr,
                    gt_text,
                    img_path
                )
                row_data.update(result)
            except Exception as e:
                print(f"   ⚠️ PaddleOCR failed: {e}")
                row_data.update({
                    "PaddleOCR_CER": 100.0,
                    "PaddleOCR_WER": 100.0,
                    "PaddleOCR_Time": 0.0,
                    "PaddleOCR_RAM_MB": 0.0,
                    "PaddleOCR_CPU_%": 0.0
                })

        all_results.append(row_data)

    # ==========================================
    # SAVE RESULTS
    # ==========================================
    print("\n" + "=" * 60)
    print("💾 SAVING RESULTS")
    print("=" * 60)

    df = pd.DataFrame(all_results)

    csv_path = os.path.join(RESULTS_DIR, "ocr_comparison_results.csv")
    df.to_csv(csv_path, index=False)

    print(f"✅ Saved to: {csv_path}\n")

    # ==========================================
    # FINAL SUMMARY
    # ==========================================
    print("📊 FINAL SUMMARY (AVERAGES)")

    models = ["TrOCR", "Tess_Raw", "Tess_Proc", "EasyOCR", "PaddleOCR"]

    for model in models:
        if f"{model}_CER" in df.columns:
            avg_cer = df[f"{model}_CER"].mean()
            avg_wer = df[f"{model}_WER"].mean()
            avg_time = df[f"{model}_Time"].mean()

            print(
                f"🔹 {model.ljust(10)} "
                f"→ CER: {avg_cer:>6.2f}% | "
                f"WER: {avg_wer:>6.2f}% | "
                f"Time: {avg_time:>5.2f}s"
            )


# ==========================================
# ENTRY POINT
# ==========================================
if __name__ == "__main__":
    main()